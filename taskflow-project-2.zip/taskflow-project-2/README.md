# TaskFlow — Project 2: Backend API Development

A beginner-friendly REST API built with Node.js and Express for DecodeLabs Full Stack Development Project 2.

## Requirements covered

- GET and POST API endpoints
- JSON request and response handling
- Basic validation for user input
- Persistent data stored in `data/tasks.json`
- Clear HTTP status codes and JSON error responses
- Resource-based REST naming (`/api/tasks`)
- Basic API documentation and test examples

## Run locally

1. Install **Node.js LTS** from https://nodejs.org if it is not installed.
2. Extract this project ZIP and open the extracted folder in VS Code.
3. In VS Code, choose **Terminal → New Terminal**.
4. Run:

   ```bash
   npm install
   npm start
   ```

5. Open `http://localhost:3000/api/health` in your browser. You should see a JSON success response.
6. Open `http://localhost:3000/api/tasks` to see the task collection.

Keep the terminal running while you test the API. Press `Ctrl + C` to stop it.

## Endpoints

| Method | Endpoint | Purpose | Success status |
| --- | --- | --- | --- |
| GET | `/api/health` | Check whether the API is running | 200 OK |
| GET | `/api/tasks` | Retrieve all tasks | 200 OK |
| GET | `/api/tasks/:id` | Retrieve one task by ID | 200 OK |
| POST | `/api/tasks` | Validate and create a task | 201 Created |

### POST example

Send a `POST` request to `http://localhost:3000/api/tasks` with header `Content-Type: application/json` and this JSON body:

```json
{
  "title": "Complete database assignment",
  "category": "Assignment",
  "priority": "High",
  "due": "2026-11-02",
  "completed": false
}
```

Example using PowerShell in the VS Code terminal:

```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:3000/api/tasks -ContentType "application/json" -Body '{"title":"Complete database assignment","category":"Assignment","priority":"High","due":"2026-11-02","completed":false}'
```

### Validation example

Try sending a blank title or an invalid priority:

```json
{
  "title": "",
  "priority": "Urgent"
}
```

The API responds with `400 Bad Request` and a JSON explanation of the validation errors.

## HTTP status codes used

- `200 OK` — a GET request succeeded.
- `201 Created` — a task was created successfully.
- `400 Bad Request` — invalid JSON or input data.
- `404 Not Found` — requested task or route does not exist.
- `500 Internal Server Error` — unexpected server-side failure.

## Project structure

```text
taskflow-project-2/
├── server.js
├── package.json
├── README.md
└── data/
    └── tasks.json
```

## Important notes

- This is a small learning project. It stores data in a local JSON file, not a production database.
- It does not implement authentication, user accounts, editing, or deleting tasks because those are beyond the core GET/POST brief.
- The API is available on your own computer at `localhost` while the server is running. A live public deployment requires a Node.js hosting service.
- Read the endpoint and validation sections before explaining the project in a review or interview.
