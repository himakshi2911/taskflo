const express = require("express");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "tasks.json");

app.disable("x-powered-by");
app.use(express.json({ limit: "20kb" }));

function ensureDataFile() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, "[]\n", "utf8");
  }
}
function readTasks() {
  ensureDataFile();
  try {
    const value = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    return Array.isArray(value) ? value : [];
  } catch {
    throw new Error("Task data could not be read. Check data/tasks.json.");
  }
}
function writeTasks(tasks) {
  ensureDataFile();
  fs.writeFileSync(DATA_FILE, JSON.stringify(tasks, null, 2) + "\n", "utf8");
}
function validDate(value) {
  return value === "" || /^\d{4}-\d{2}-\d{2}$/.test(value);
}
function validateTask(body) {
  const errors = [];
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return ["Request body must be a JSON object."];
  }
  if (typeof body.title !== "string" || body.title.trim().length < 1) {
    errors.push("title is required and must not be empty.");
  } else if (body.title.trim().length > 120) {
    errors.push("title must be 120 characters or fewer.");
  }
  if (body.category !== undefined &&
      (typeof body.category !== "string" || body.category.trim().length > 40)) {
    errors.push("category must be text with at most 40 characters.");
  }
  if (body.priority !== undefined &&
      !["Low", "Medium", "High"].includes(body.priority)) {
    errors.push("priority must be Low, Medium, or High.");
  }
  if (body.due !== undefined &&
      (typeof body.due !== "string" || !validDate(body.due))) {
    errors.push("due must be an empty string or a date in YYYY-MM-DD format.");
  }
  if (body.completed !== undefined && typeof body.completed !== "boolean") {
    errors.push("completed must be true or false.");
  }
  return errors;
}

app.get("/api/health", (_req, res) => {
  res.status(200).json({
    success: true,
    message: "TaskFlow API is running.",
    timestamp: new Date().toISOString()
  });
});

// GET /api/tasks — retrieve the current task collection.
app.get("/api/tasks", (_req, res, next) => {
  try {
    const tasks = readTasks();
    res.status(200).json({ success: true, count: tasks.length, data: tasks });
  } catch (error) {
    next(error);
  }
});

// GET /api/tasks/:id — retrieve one task.
app.get("/api/tasks/:id", (req, res, next) => {
  try {
    const task = readTasks().find(item => item.id === req.params.id);
    if (!task) {
      return res.status(404).json({
        success: false,
        error: { code: "TASK_NOT_FOUND", message: "No task exists with that id." }
      });
    }
    return res.status(200).json({ success: true, data: task });
  } catch (error) {
    return next(error);
  }
});

// POST /api/tasks — validate and create a task.
app.post("/api/tasks", (req, res, next) => {
  try {
    const errors = validateTask(req.body);
    if (errors.length) {
      return res.status(400).json({
        success: false,
        error: { code: "VALIDATION_ERROR", message: "Please correct the submitted data.", details: errors }
      });
    }
    const tasks = readTasks();
    const task = {
      id: crypto.randomUUID(),
      title: req.body.title.trim(),
      category: (req.body.category || "Study").trim(),
      priority: req.body.priority || "Medium",
      due: req.body.due || "",
      completed: req.body.completed ?? false,
      createdAt: new Date().toISOString()
    };
    tasks.push(task);
    writeTasks(tasks);
    return res.status(201).location(`/api/tasks/${task.id}`).json({
      success: true,
      message: "Task created successfully.",
      data: task
    });
  } catch (error) {
    return next(error);
  }
});

// JSON syntax errors are reported clearly instead of returning an HTML error page.
app.use((error, _req, res, _next) => {
  if (error instanceof SyntaxError && error.status === 400 && "body" in error) {
    return res.status(400).json({
      success: false,
      error: { code: "INVALID_JSON", message: "Request body must contain valid JSON." }
    });
  }
  console.error(error);
  return res.status(500).json({
    success: false,
    error: { code: "INTERNAL_SERVER_ERROR", message: "An unexpected server error occurred." }
  });
});

app.use((_req, res) => {
  res.status(404).json({
    success: false,
    error: { code: "ROUTE_NOT_FOUND", message: "This API route does not exist." }
  });
});

app.listen(PORT, () => {
  ensureDataFile();
  console.log(`TaskFlow API running at http://localhost:${PORT}`);
  console.log("Try GET http://localhost:" + PORT + "/api/tasks");
});
