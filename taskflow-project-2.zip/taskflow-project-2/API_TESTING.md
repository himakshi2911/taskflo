# Quick API Testing Checklist

Run `npm install` and `npm start` first.

## 1. Health check
- Method: `GET`
- URL: `http://localhost:3000/api/health`
- Expected: `200 OK`, with `"success": true`.

## 2. List tasks
- Method: `GET`
- URL: `http://localhost:3000/api/tasks`
- Expected: `200 OK`, a `count`, and a `data` array.

## 3. Create a valid task
- Method: `POST`
- URL: `http://localhost:3000/api/tasks`
- Header: `Content-Type: application/json`
- Body:
```json
{
  "title": "Prepare project report",
  "category": "Assignment",
  "priority": "Medium",
  "due": "",
  "completed": false
}
```
- Expected: `201 Created`, a generated ID, and the created task.

## 4. Test validation
Repeat the POST with `"title": ""`.
- Expected: `400 Bad Request`, code `VALIDATION_ERROR`.

## 5. Test a missing ID
- Method: `GET`
- URL: `http://localhost:3000/api/tasks/not-a-real-id`
- Expected: `404 Not Found`, code `TASK_NOT_FOUND`.

## 6. Check persistence
Create a task, stop the server with `Ctrl + C`, start it again with `npm start`, and GET `/api/tasks`.
- Expected: the created task remains in `data/tasks.json`.
